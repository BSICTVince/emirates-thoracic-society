<?php
// php code here for additional functionalities
$assetPath     = ".";
$url     = "";
$pageTitle = "Emirates Thoracic Society";
$pageHeading = "";
$description = "";
$keywords   = "";


?>

<!DOCTYPE html>
<html lang="en">
    <?php // php code here for additional functionalities
include 'template-parts/header.php'; ?>

    <body>
        <div class="header-wrapper">
            <!-- ✅ Background Video Overlay -->

            <div class="video-overlay-wrapper position-absolute top-0 start-0 w-100 h-100 z-0">
                <div class="video-fade">
                    <video autoplay muted loop playsinline class="w-100 h-100 object-fit-cover">
                        <source src="assets/images/hero-video.mp4" type="video/mp4" />
                        Your browser does not support the video tag.
                    </video>
                </div>
            </div>

            <!-- Optional: Background image to show through the transparent edges -->
            <img src="./assets/images/hero-banner.jpg" alt="Hero Background" class="position-absolute top-0 start-0 w-100 h-100 object-fit-cover z-0" style="opacity: 0.01;" />

            <?php // navigation menu
    include 'template-parts/navigation.php'; ?>

            <!-- Hero Section -->
            <!-- <header id="hero" class="hero-section position-relative text-white text-center d-flex align-items-center justify-content-center">
    <img src="./assets/images/hero-banner.jpg" alt="Hero banner" class="img-fluid position-absolute">
    <div class="container-fluid position-relative p-0 m-0">
      <div class="d-flex flex-column align-items-start justify-content-center hero-content-overlay">
        <img src="./assets/images/logo-bare.png" alt="ETS Hero Logo" class="mb-4" style="max-width: 200px; height: auto;">
        <h1 class="display-4 fw-bold mb-0">Emirates Thoracic Society</h1>
        <p class="lead">Leading Respiratory Health Initiatives</p>
      </div>
    </div>
 </header> -->

            <div class="container fade-in-up">
                <div class="banner-content">
                    <img src="./assets/images/logo-bare.png" class="img-fluid" />
                    <h3><strong>Emirates Thoracic Society</strong></h3>
                    <p>Leading Respiratory Health Initiatives</p>
                </div>
                <!-- <div class="banner-bg-img">
        <img src="assets/images/Ellipse.png">
      </div> -->
            </div>

            <div class="banner-hero-bottom">
                <img src="assets/images/hero-bottom.png" class="img-fluid" />
            </div>
        </div>

        <!-- About Section -->
        <section id="about" class="py-5 bg-white about-section">
            <div class="container fade-in-up">
                <div class="row">
                    <div class="col-12 col-lg-8 pb-3 pb-lg-0">
                        <h2 class="display-5 fw-bold mb-0">Emirates Thoracic Society (ETS)</h2>
                        <h3 class="display-6">Leading Respiratory Health Initiatives</h3>
                        <p class="lead">
                            Respiratory diseases continue to be a major health concern in the UAE, affecting individuals of all ages. The Emirates Thoracic Society (ETS) is committed to raising awareness, promoting early diagnosis, and
                            enhancing the management of respiratory conditions through scientific research, educational programs, and public health campaigns.
                        </p>
                        <p class="lead">
                            As the official respiratory society in the UAE, ETS operates under the Emirates Medical Association, which has been a cornerstone of medical advancement since 1980. ETS serves as a vital platform for
                            pulmonologists, healthcare professionals, and patients by offering up-to-date guidelines, expert-led symposiums, and a wealth of online resources dedicated to respiratory health.
                        </p>
                        <button type="button" class="btn rounded-0 text-white">Read About Us</button>
                    </div>
                    <div class="col-12 col-lg-4">
                        <img src="./assets/images/about-img.png" style="width: 100%;" alt="" />
                    </div>
                </div>
            </div>
        </section>

        <!-- About Section 2 -->
        <img src="./assets/images/about-bottom.png" style="width: 100%;" alt="" />

        <section id="about-2" class="about-section-2">
            <div class="container fade-in-up">
                <div class="row">
                    <div class="col-12 col-lg-8 text-white">
                        <h4 class="display-6 fw-bold mb-0 text-color-tertiary">Emirates Thoracic Society (ETS)</h4>
                        <h2 class="display-5">Leading Respiratory Health Initiatives</h2>
                        <p class="lead">
                            Platform uniting pulmonologists, healthcare professionals, and patients with a shared commitment to advancing respiratory health, fostering knowledge exchange, and improving the quality of care in the United Arab
                            Emirates.
                        </p>
                        <p class="lead">
                            As respiratory diseases continue to present significant challenges, ETS remains dedicated to providing the latest medical insights, organizing scientific conferences, conducting specialized training workshops,
                            and leading impactful awareness initiatives to promote a healthier community.
                        </p>
                        <p class="lead">
                            In 2025 and beyond, we strive to expand our activities, strengthen collaborations among experts, and support cutting-edge research in respiratory medicine. I invite you to explore our website, take advantage of
                            its valuable resources, and join us in our mission to shape a future of better respiratory health for all.
                        </p>
                    </div>
                    <div class="col-12 col-lg-4">
                        <img src="./assets/images/about-img-2.png" style="width: 100%;" alt="" />
                        <br />
                        <div class="prof-name ps-5 py-5">
                            <h3>PROF. ASHRAF ALZAABI</h3>
                            <h4>PRESIDENT, EMIRATES THORACIC SOCIETY</h4>
                        </div>
                    </div>
                </div>
            </div>

            <div class="hero-bottom">
                <img src="assets/images/hero-bottom.png" class="img-fluid" />
            </div>
        </section>

        <section class="ets-goal w-100" style="position: relative;">
            <div class="container d-flex justify-content-center align-items-center">
                <div class="row vh-100 fade-in-up">
                    <div class="d-flex flex-column flex-lg-row justify-content-center align-items-center">
                        <div class="col-12 col-lg-4">
                            <h2 class="display-5 text-color-primary fw-bold">Our Main Goal</h2>
                            <p class="text-justify fade-in-up lead">
                                To reduce the impact of Emirates Thoracic Society (ETS) and related conditions by advancing prevention, treatment, and support through specialized care and research.
                            </p>
                        </div>
                        <div class="col-12 col-lg-8">
                            <!-- Image or illustration goes here -->
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="about-3" class="gallery-wrapper">
            <!-- 
    <div class="thumbnail-img">
      <div class="main-img">
        <img src="assets/images/gallery-main.png" alt="">
      </div>
      <div class="container about-3-details">
        <h4>OUR MAIN GOAL</h4>
        <p>To reduce the impact of Emirates Thoracic Society (ETS) and related conditions by advancing prevention,
          treatment, and support through specialized care and research.</p>
      </div>
    </div>
-->
            <div class="sub-img py-2">
                <img src="assets/images/gallery-1.png" />
                <img src="assets/images/gallery-2.png" />
                <img src="assets/images/gallery-3.png" />
                <img src="assets/images/gallery-4.png" />
            </div>
        </section>

        <section id="about-4" class="mission-vission">
            <div class="container fade-in-up">
                <h3 class="text-center text-color-secondary"><strong>ETS MISSION & VISSION</strong></h3>
                <div class="row">
                    <div class="col-lg-6 col-sm-12 pt-2">
                        <div class="ev-wrap">
                            <h5>Mission</h5>
                            <p class="lead">
                                The Emirates Thoracic Society (ETS) is committed to advancing respiratory health in the UAE by fostering excellence in patient care, medical education, scientific research, and public awareness. Through
                                multidisciplinary collaboration, ETS aims to support healthcare professionals with cutting-edge knowledge, facilitate early detection and effective management of respiratory diseases, and advocate for
                                policies that improve lung health. By integrating evidence-based practices, continuous professional development, and community outreach, ETS strives to elevate respiratory care standards and enhance the
                                quality of life for individuals affected by pulmonary conditions.
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-12 pt-2">
                        <div class="ev-wrap">
                            <h5>Vision</h5>
                            <p class="lead">
                                To be the foremost authority in respiratory medicine in the UAE and the wider region, leading the way in innovation, education, and research to combat respiratory diseases. ETS envisions a future where
                                advancements in pulmonary medicine translate into improved healthcare outcomes, where public awareness empowers individuals to take charge of their respiratory health, and where strong partnerships between
                                medical professionals, academic institutions, and policymakers drive sustainable improvements in lung health. Through scientific excellence and strategic initiatives, ETS aspires to shape the future of
                                respiratory care, ensuring healthier communities for generations to come.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="ask-question-form-section">
            <div class="container fade-in-up">
                <div class="ask-question-form bg-white shadow p-4 p-md-5 rounded">
                    <h3 class="text-color-secondary text-center mb-2 fw-bold">Ask a Question</h3>
                    <p class="text-center text-color-primary text-muted mb-4" style="font-size: 28px;">Connect with the leaders in the society</p>
                    <form class="contact-form">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <input type="text" class="form-control" placeholder="First Name" required />
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control" placeholder="Last Name" required />
                            </div>
                            <div class="col-md-6">
                                <input type="email" class="form-control" placeholder="Email" required />
                            </div>
                            <div class="col-md-6">
                                <input type="text" class="form-control" placeholder="Phone" />
                            </div>
                            <div class="col-12">
                                <input type="text" class="form-control" placeholder="Interest Area" />
                            </div>
                            <div class="col-12">
                                <textarea class="form-control" placeholder="Message" rows="5"></textarea>
                            </div>
                            <div class="col-12 text-left">
                                <button type="submit" class="btn btn-success px-5">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>

        <section class="endorsement-request d-flex align-items-center justify-content-center text-center text-white">
            <div class="container fade-in-up">
                <h2 class="mb-3 text-size-44">Endorsement Request</h2>
                <p class="mb-2 lead">
                    For activity endorsement by the ETS Society, kindly download and fill in the form and send it to:
                    <a href="mailto:events@mco.ae" class="text-white fw-bold text-decoration-none"><span style="color: #138a44;">events@mco.ae</span></a>
                </p>
                <!-- <a href="path-to-form.pdf" class="btn btn-outline-light mt-3" download>Download Form</a> -->
                <a href="#" class="btn btn-success border-0">Download Form</a>
            </div>
        </section>

        <?php // php code here for additional functionalities
include 'template-parts/footer.php'; ?>
    </body>
</html>
