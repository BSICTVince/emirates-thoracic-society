<?php
// php code here for additional functionalities
$assetPath = ".";
$url     = 
$pageTitle = "ETS BOARD MEMBERS";
$pageHeading = "ETS BOARD MEMBERS";
$description = "Emirates Thoracic Society member colleagues joining forces";
$keywords   = "test";

?>
<!DOCTYPE html>
<html lang="en">
    <?php // php code here for additional functionalities
        include './template-parts/header.php'; ?>

    <body>
        <div class="">
            <?php // navigation menu
         include './template-parts/navigation.php'; ?>

            <div class="container fade-in-up">
                <div class="row">
                    <div class="col-12 d-flex justify-content-center align-items-center text-center">
                        <div class="p-4 p-md-5">
                            <h3 class="form-title text-center text-color-dark mb-3 fw-bold fs-2">Our Board Members</h3>
                        </div>
                    </div>
                </div>

                <div class="row justify-content-center text-center g-4">
                    <div class="board-member col-12 col-sm-6 col-lg-2 fade-in-up ">
                        <div class="image-container">
                            <img src="<?php echo $assetPath; ?>/assets/images/Path.png" class="background-img" />
                            <img src="<?php echo $assetPath; ?>/assets/images/1.png" class="foreground-img" />
                        </div>
                        <h4 class="name-member text-color-primary">Dr. Abubaker Almadani</h4>
                        <p class="position fw-bold">Vice President</p>
                    </div>

                    <div class="board-member col-12 col-sm-6 col-lg-2 fade-in-up">
                        <div class="image-container">
                            <img src="<?php echo $assetPath; ?>/assets/images/Path.png" class="background-img" />
                            <img src="<?php echo $assetPath; ?>/assets/images/2.png" class="foreground-img" />
                        </div>
                        <h4 class="name-member text-color-primary">Dr. Salama Karmastaji</h4>
                        <p class="position fw-bold">General Secretary</p>
                    </div>

                    <div class="board-member col-12 col-sm-6 col-lg-2 fade-in-up">
                        <div class="image-container">
                            <img src="<?php echo $assetPath; ?>/assets/images/Path.png" class="background-img" />
                            <img src="<?php echo $assetPath; ?>/assets/images/3.png" class="foreground-img" />
                        </div>
                        <h4 class="name-member text-color-primary">Dr. Mohammed Alkuwaiti</h4>
                        <p class="position fw-bold">Scientific Committee Chairperson</p>
                    </div>

                    <div class="board-member col-12 col-sm-6 col-lg-2 fade-in-up">
                        <div class="image-container">
                            <img src="<?php echo $assetPath; ?>/assets/images/Path.png" class="background-img" />
                            <img src="<?php echo $assetPath; ?>/assets/images/4.png" class="foreground-img" />
                        </div>
                        <h4 class="name-member text-color-primary">Dr. Reem Alsuwaidi</h4>
                        <p class="position fw-bold">Media & Public Relations Chairperson</p>
                    </div>

                    <div class="board-member col-12 col-sm-6 col-lg-2 fade-in-up">
                        <div class="image-container">
                            <img src="<?php echo $assetPath; ?>/assets/images/Path.png" class="background-img" />
                            <img src="<?php echo $assetPath; ?>/assets/images/5.png" class="foreground-img" />
                        </div>
                        <h4 class="name-member text-color-primary">Dr. Shivam Om Mittal</h4>
                        <p class="position fw-bold">Board Member</p>
                    </div>
                </div>
            </div>
        </div>

        <?php // php code here for additional functionalities
    include './template-parts/footer.php'; ?>
    </body>
</html>
