<?php
// php code here for additional functionalities
$assetPath = ".";
$url     = "";
$pageTitle = "Contact Us";
$pageHeading = "";
$description = "";
$keywords   = "";
?>
<!DOCTYPE html>
<html lang="en">

<?php // php code here for additional functionalities
include './template-parts/header.php'; ?>

<body>


    <div class="">





       
         <?php // navigation menu
         include './template-parts/navigation.php'; ?>

        <section class="contact-us-form d-flex align-items-lg-center justify-content-lg-center">
            <div class="container rounded fade-in-up">
                <div class="row justify-content-center align-items-center g-4">

                    <!-- 🔷 Logo Column -->
                    <div class="col-12 col-lg-2 text-center text-md-start">
                        <img src="<?php echo $assetPath; ?>/assets/images/logo-bare.png" alt="Logo" class="img-fluid" style="max-width: 180px;">


                        <div class="d-flex flex-column px-3 py-2 gap-3 mb-3 fw-bold">
                            <span><i class="fa-solid fa-envelope me-2 text-success"></i> events@mco.ae</span>
                            <span><i class="fa-solid fa-phone me-2 text-success"></i> +971588645471</span>
                        </div>

                    </div>

                    <!-- 🔶 Form Column -->
                   <div class="col-12 col-lg-6">
						<div class="p-4 p-md-5">
							<h3 class="form-title text-color-dark text-left mb-4 fw-bold fs-2">
								DON'T HESITATE TO CONTACT US
									</h3>
										<form id="contact-us">
											<div class="row g-4">
											<div class="col-md-12">
											<input type="text" class="form-control form-control-lg shadow-br" placeholder="Your Name" required>
											</div>
												<div class="col-md-12">
													<input type="email" class="form-control form-control-lg shadow-br" placeholder="Your Email" required>
													</div>
													<div class="col-12">
												<textarea class="form-control form-control-lg shadow-br" placeholder="Your Message (Optional)" rows="5"></textarea>
											</div>
										<div class="col-12 text-start">
									<button type="submit" class="btn btn-success btn-lg px-5 py-2">Submit</button>
								</div>
							</div>
						</form>
					</div>
				</div>


                </div>
            </div>


        </section>


       


        
    <?php // php code here for additional functionalities
    include './template-parts/footer.php'; ?>



</body>

</html>
