<?php


?>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!--✅ Meta SEO -->
    <title><?php echo isset($pageTitle) ? $pageTitle : 'Emirates Thoracic Society'; ?></title>
    <meta name="description" content="<?php echo isset($description) ? $description : ''; ?>" />
    <meta name="keywords" content="<?php echo isset($keywords) ? $keywords : ''; ?>" />

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>


      <!-- Dynamic Asset Linking -->
    <link rel="stylesheet" href="<?php echo $assetPath; ?>/assets/css/styles.css" />
    <link rel="stylesheet" href="<?php echo $assetPath; ?>/assets/css/animation.css" />
    <link rel="stylesheet" href="<?php echo $assetPath; ?>/assets/css/responsive.css" />
    <link rel="stylesheet" href="<?php echo $assetPath; ?>/assets/css/navigation.css" />
    <link rel="icon" href="<?php echo $assetPath; ?>/assets/images/favicon.png" type="image/png">


    <!-- Font Awesome 6 Free CDN -->
    <script src="https://kit.fontawesome.com/9f6e90d4ba.js" crossorigin="anonymous"></script>
</head>

