<?php
?>
    <section class="follow-up text-center py-5">
            <div class="contact-us-bottom-img">
                <img src="<?php echo $assetPath; ?>/assets/images/hero-bottom.png" class="img-fluid" />
            </div>

            <div class="container fade-in-up">
                <h2 class="text-success mb-3">Follow up</h2>
                <p class="mb-3">To get in touch with ETS for any enquiries, please send an email to</p>

                <!-- Social Icons -->
                <div class="d-inline-flex px-3 py-2 gap-3 mb-3">
                    <a href="#" class="text-success fs-5"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="text-success fs-5"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="text-success fs-5"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#" class="text-success fs-5"><i class="fab fa-tiktok"></i></a>
                </div>

                <!-- Email -->
                <p class="mb-0 text-success">Email: <a href="mailto:events@mco.ae" class="text-success">events@mco.ae</a></p>
            </div>
        </section>
        
<footer class="text-center text-muted py-2 mt-auto">
    <div class="text-white container px-3 fade-in-up fw-bold lead">
      <small>
       Copyright &copy; Emirates Thoracic Society <?php echo date('Y'); ?>. All Rights Reserved |
        Website developed and maintained by: MCO
      </small>
    </div>

  </footer>

<script src="<?php echo $assetPath; ?>/assets/js/script.js"></script>