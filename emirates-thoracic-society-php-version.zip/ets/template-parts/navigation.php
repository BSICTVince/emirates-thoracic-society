<?php
// php code here for additional functionalities
?>

<!-- Header -->
<div class="header-top container-fluid">
    <div class="container-xl d-flex justify-content-between align-items-center position-relative">
        <div class="membership-buttons ms-auto d-flex flex-column flex-md-row">
            <a href="#" class="btn btn-success border-0">Become an EMA Member</a>
            <a href="#" class="btn btn-success border-0">Become an ETS Member</a>
        </div>
    </div>

    <!-- Overlapping Logo -->
    <div class="logo text-center">
        <a href="/"><img src="<?php echo $assetPath; ?>/assets/images/logo.png" class="img-fluid" alt="ETS Logo" /></a>
    </div>
</div>

<nav class="navbar navbar-expand-lg navbar-dark nav_backcolor nav-rtl">
    <div class="container-xl flex-row-reverse">
        <!-- <a class="navbar-brand fw-bold" href="#">
        <img src="./assets/images/logo.png" alt="logo" width="225" height="146">
      </a> -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse nav-menu-style" id="navbarSupportedContent">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                <li class="nav-item d-flex justify-content-end">
                    <a class="nav-link active" aria-current="page" href="' . route('home')">Home</a>
                </li>
                <li class="nav-item d-flex justify-content-end">
                    <a class="nav-link" href="about-us.php" target="_blank" rel="noopener noreferrer">About us</a>
                </li>
                <li class="nav-item d-flex justify-content-end">
                    <a class="nav-link" href="board-members.php" target="_blank" rel="noopener noreferrer">ETS Board Members</a>
                </li>
                <li class="nav-item d-flex justify-content-end">
                    <a class="nav-link" href="special-interest.php" target="_blank" rel="noopener noreferrer">ETS Special Interest</a>
                </li>
                <li class="nav-item dropdown d-flex flex-wrap flex-column align-content-end align-items-end flex-lg-row justify-content-end">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Conferences
                    </a>

                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <!-- Upcoming Events with Submenu -->
                        <li class="dropdown dropend">
                            <a class="dropdown-item dropdown-toggle submenu-toggle" href="#" id="upcomingEventsDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                Upcoming Events
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="upcomingEventsDropdown">
                                <li><a class="dropdown-item" href="https://etsociety.ae/2025/" target="_blank" rel="noopener noreferrer">2025 Congress</a></li>
                            </ul>
                        </li>

                        <!-- Previous Events with Submenu -->
                        <li class="dropdown dropend">
                            <a class="dropdown-item dropdown-toggle submenu-toggle" href="#" id="previousEventsDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                Previous Events
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="previousEventsDropdown">
                                <li><a class="dropdown-item" href="#" target="_blank" rel="noopener noreferrer">2024 Congress</a></li>
                                <li><a class="dropdown-item" href="#" target="_blank" rel="noopener noreferrer">2023 Congress</a></li>
                                <li><a class="dropdown-item" href="#" target="_blank" rel="noopener noreferrer">2022 Congress</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li class="nav-items d-flex justify-content-end">
                    <a class="nav-link" href="contact-us.php" target="_blank" rel="noopener noreferrer">Contact us</a>
                </li>
            </ul>
            <ul class="navbar-nav d-flex flex-row justify-content-end">
                <li class="nav-item me-3 me-lg-1">
                    <a class="nav-link soc-med-icon-style" href="#"><img src="<?php echo $assetPath; ?>/assets/images/Icon-awesome-facebook-f.png" class="mx-auto" alt="" /></a>
                </li>
                <li class="nav-item me-3 me-lg-1">
                    <a class="nav-link soc-med-icon-style" href="#"><img src="<?php echo $assetPath; ?>/assets/images/Icon-metro-instagram.png" class="mx-auto" alt="" /></a>
                </li>
                <li class="nav-item me-3 me-lg-1">
                    <a class="nav-link soc-med-icon-style" href="#"><img src="<?php echo $assetPath; ?>/assets/images/Icon-awesome-linkedin-in.png" class="mx-auto" alt="" /></a>
                </li>
                <li class="nav-item me-3 me-lg-1">
                    <a class="nav-link soc-med-icon-style" href="#"><img src="<?php echo $assetPath; ?>/assets/images/Icon-simple-tiktok.png" class="mx-auto" alt="" /></a>
                </li>
            </ul>
        </div>
    </div>
</nav>



