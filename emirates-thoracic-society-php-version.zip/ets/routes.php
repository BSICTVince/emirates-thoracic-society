<?php
// routes.php
return [
    'home' => 'index.php',
    'about-us' => 'pages/about-us.php',
    'contact-us' => 'pages/contact-us.php',
];