<?php
// php code here for additional functionalities
$assetPath = ".";
$url = "";
$pageTitle = "About Us";
$pageHeading = "";
$description = "";
$keywords   = "";
?>
<!DOCTYPE html>
<html lang="en">
    <?php // php code here for additional functionalities
include './template-parts/header.php'; ?>

    <body>
        <?php // navigation menu
         include './template-parts/navigation.php'; ?>

        <section class="contact-us-form d-flex align-items-lg-center justify-content-lg-center">
            <div class="col-12 col-lg-6 d-flex justify-content-center align-items-center text-center">
                <div class="p-4 p-md-5">
                    <h3 class="form-title text-color-dark mb-3 fw-bold fs-2">TO BE ADDED SOON</h3>
                </div>
            </div>
        </section>

        <?php // php code here for additional functionalities
    include './template-parts/footer.php'; ?>
    </body>
</html>
