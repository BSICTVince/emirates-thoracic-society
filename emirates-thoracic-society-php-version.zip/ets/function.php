<?php

// functions.php
function route($name) {
    $routes = include 'routes.php';
    return isset($routes[$name]) ? 'index.php?page=' . $name : '#';
}
